var len1 = document.querySelector('#legend1');
var len2 = document.querySelector('#legend2');
var set1 = document.querySelector('#set1');
var set2 = document.querySelector('#set2');
var le1 = len1.querySelector('legend');
var le2 = len2.querySelector('legend');
le1.style.border = '1px solid #e5e5e5'
le1.style.background = '-webkit-gradient(linear, 0% 0%, 0% 100%,from(#f6f6f8), to(#b8c4cb))'
le1.style.borderRadius = '5px'
le2.style.borderRadius = '5px'
le2.style.border = '1px solid #e5e5e5'
len1.onclick = function(){
	set1.style.display = 'block';
	set2.style.display = 'none';
	le1.style.background = '-webkit-gradient(linear, 0% 0%, 0% 100%,from(#f6f6f8), to(#b8c4cb))'
	
	le2.style.background = ''
}

len2.onclick = function(){
	set2.style.display = 'block';
	set1.style.display = 'none';
	le1.style.background = '';
	le2.style.background = '-webkit-gradient(linear, 0% 0%, 0% 100%,from(#f6f6f8), to(#b8c4cb))'
	
	
}


var mail = /^([A-z]\w{5,17})$/;
var pwd = /^\w{6,16}$/;
var pwd1 = /^\d{6,16}$/;
var pwd2 = /^(?=.{6,16})(?=(?:.*?[!@#$%*()_+^&}{:;?.]){1})(?=.*[a-z])(?=.*[0-9])(?=.*\\W).*$/;
var pwd3 = /^(?=.{6,16})(((?=.*[A-Z])(?=.*[a-z]))|((?=.*[A-Z])(?=.*[0-9]))|((?=.*[a-z])(?=.*[0-9]))).*$/;
var phone = /^((13|18)(\d{9}))$|^(14[57]\d{8})$|^(17[07]\d{8})$|(^15[0-35-9]\d{8}$)/;
var checkCode = /^aaaa$/
var in1 = document.querySelector('#in_mail_1')
in1.oninput = function getMail(){
	var logP = $(this).next().next()[0]
	var a = this.value;
	if(mail.test(a) == true){
		logP.innerHTML = '恭喜您，可以注册';
	}else if(phone.test(a) == true){
		logP.innerHTML = '恭喜您，可以用此手机号码注册';
	}else if(a == ''){
		logP.innerHTML = '用户名不可以为空';
	}else{
		logP.innerHTML = '请输入6~18个字符，可使用字母、数字、下划线，需以字母开头';
	}
}


var phoneCode = document.querySelector('#phone_code');
phoneCode.oninput = function phone_check(){
	var logP = $(this).next().next()[0]
	var a  = this.value;
	if(phone.test(a) == true){
		logP.innerHTML = '手机号码正确'
	}else{
		logP.innerHTML = '请输入正确的11位中国大陆手机号码'
	}
}

var in2 = document.querySelector('#in_pwd_1')
var code1 = document.querySelector('#code1');
code1.oninput = function pass(){
	var logP = $(this).next()[0]
	var a  = this.value;
	if(pwd.test(a) == true){
		logP.innerHTML = '密码强度：弱'
	}else if(pwd1.test(a) == true){
		logP.innerHTML = '请不要使用纯数字密码'
	}else if(pwd2.test(a) == true){
		logP.innerHTML = '密码强度：高'
	}else if(pwd3.test(a)){
		logP.innerHTML = '密码强度：中'
	}else{
		logP.innerHTML = '6~16个字符，区分大小写'
	}
}
in2.oninput = function pass(){
	var logP = $(this).next()[0]
	var a  = this.value;
	if(pwd.test(a) == true){
		logP.innerHTML = '密码强度：弱'
	}else if(pwd1.test(a) == true){
		logP.innerHTML = '请不要使用纯数字密码'
	}else if(pwd2.test(a) == true){
		logP.innerHTML = '密码强度：高'
	}else if(pwd3.test(a)){
		logP.innerHTML = '密码强度：中'
	}else{
		logP.innerHTML = '6~16个字符，区分大小写'
	}
}



var in_check = document.querySelector('#in_pwd_1_check_1')
var code2 = document.querySelector('#code2');
code2.oninput = function check(){
	var logP = $(this).next()[0]
	var a  = this.value;
	if(a == $('#code1').val()){
		logP.innerHTML = '两次输入相同'
	}else{
		logP.innerHTML = '两次输入不相同，请重新输入'
	}
}
in_check.oninput = function check(){
	var logP = $(this).next()[0]
	var a  = this.value;
	if(a == $('#in_pwd_1').val()){
		logP.innerHTML = '两次输入相同'
	}else{
		logP.innerHTML = '两次输入不相同，请重新输入'
	}
}


var code = document.querySelector('#phone');
code.oninput = function phone_check(){
	
	var logP = $(this).next()[0]
	var a  = this.value;
	if(phone.test(a) == true){
		logP.innerHTML = '手机号码正确'
	}else{
		logP.innerHTML = '请输入正确的11位中国大陆手机号码'
	}
}

var check_code = document.querySelector('#check')
var picCheck = document.querySelector('#pic_check');
picCheck.oninput = function check_code(){
	var logP = $(this).next()[0]
	var a  = this.value;
	if(checkCode.test(a) == true){
		logP.innerHTML = '输对了 你个小逗比'
	}else{
		logP.innerHTML = '我才不告诉你验证码是aaaa呢'
	}
	
}
check_code.oninput = function check_code(){
	var logP = $(this).next()[0]
	var a  = this.value;
	if(checkCode.test(a) == true){
		logP.innerHTML = '输对了 你个小逗比'
	}else{
		logP.innerHTML = '我才不告诉你验证码是aaaa呢'
	}
	
}









